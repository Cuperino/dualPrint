Single OS Detect custom blocks for Illumination Software Creator
by Javier Oscar Cordero Pérez <javier.cordero@upr.edu>
License: FreeBSD

Supported Platforms: Python, HTML5/javascript, Adobe Flex.
Supported OSs: Linux, Mac OSX, Windows.
Blocks check if the App is running on one of the desktop operating systems and continue the block sequence accordingly.


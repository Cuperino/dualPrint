package com.isc.dualPrint;
import android.app.Activity;
import android.os.Handler;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.os.Bundle;
import android.widget.Toast;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.ListView;
import android.widget.ArrayAdapter;
import java.util.Hashtable;
import android.widget.AdapterView;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.AdapterView.OnItemClickListener;
import android.widget.EditText;
import android.view.View.OnKeyListener;
import android.view.KeyEvent;
import android.widget.ProgressBar;
import java.util.Random;
import android.widget.TextView;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.BufferedReader;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import java.util.ArrayList;
import java.util.Arrays;
//EndImports

public class dualPrint extends Activity {
public String iscVtotalPages = "";
public String iscVtotal = "Total: ";
public String iscVlink_pHelp_A = "http://www.dualprint.org/";
public String iscVnullText = "";
public String iscVlink = "";
public String iscVwImpar = "";
public int iscVqDifference = 0;
public int iscVqTest = 0;
public String iscVcountText = "countText";
public int iscVn1 = 1;
public String iscVwrite = "write";
public String iscVwPar = "";
public String iscVstartText = "1";
public String iscVslText = "4";
public String iscVnText = "12";
public int iscVcount = 0;
public int iscVstart = 1;
public int iscVsl = 4;
public int iscVn = 12;
public String iscVguion = "-";
public String iscVcoma = ",";
public int iscVn2 = 2;
public String iscVNotifyOSD_Imp = "notify-send \'dualPrint: Odd Copy\' \'The first print set has been copied to the clipboard. You may paste it in the print dialog.\'";
public String iscVNotifyOSD_Par = "notify-send \'dualPrint: Even Copy\' \'The seccond print set has been copied to the clipboard. You may paste it in the print dialog.\'";
public String iscVlink_web = "http://sourceforge.net/projects/dualprint/";
public String iscVlink_license = "http://www.opensource.org/licenses/MIT";
public int iscVwAbout = 0;
public String iscVlink_pHelp = "redirect.html";
public int iscVcapAndro = 78;
public String iscVparImpTest = "";
public int iscVnm1 = 1;
public int iscVn2m = 2;
public int iscVn0 = 0;
public int iscVn4 = 4;
public int iscVn6 = 6;
public int iscVn8 = 8;
public int iscVcapApple = 5000;
private WebView iscWindow151WebBrowser0;
private Button iscWindow151return0;

private ImageView iscWindow148icon0;
private TextView iscWindow148info0;
private TextView iscWindow148rights0;
private Button iscWindow148close0;
private Button iscWindow148web0;
private TextView iscWindow148MIT0;
private TextView iscWindow148version0;
private TextView iscWindow148dualprint0;
private Button iscWindow148license0;
private TextView iscWindow148illumination0;
private TextView iscWindow148info10;
private TextView iscWindow148info20;
private TextView iscWindow148MIT10;

private TextView iscWindow15nQ0;
private TextView iscWindow15slidesQ0;
private EditText iscWindow15n0;
private EditText iscWindow15sl0;
private Button iscWindow15bStart0;
private TextView iscWindow15inicioQ0;
private EditText iscWindow15start0;
private TextView iscWindow15infoImpar0;
private EditText iscWindow15wImpar0;
private TextView iscWindow15parInfo0;
private EditText iscWindow15wPar0;
private ImageView iscWindow15CI0;
private ImageView iscWindow15CP0;
private Button iscWindow15about0;
private Button iscWindow15paper0;
private ImageView iscWindow15header0;

//EndOfGlobalVariables


@Override
public void onCreate(Bundle savedInstanceState) {
super.onCreate(savedInstanceState);
iscWindow15();
//iscApp1Launched
}

private class ISCWebViewClient extends WebViewClient {
@Override
public boolean shouldOverrideUrlLoading(WebView view, String url) {
view.loadUrl(url);
return true;
}
}

public void iscTargetIs1()
{
iscClipboard_Copy4();
iscTargetIs11();
//iscTargetIs1Android
}


public void iscTargetIs2()
{
iscClipboard_Copy10();
iscTargetIs8();
//iscTargetIs2Android
}


public void iscClipboard_Copy4()
{
// get the char sequence//  CharSequence displayContents = resultHandler.getDisplayContents();//  ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);// set the contents//  clipboard.setText(iscVwImpar);//iscClipboard_Copy4Done}


public void iscMessageBox5()
{
AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
alertbox.setMessage("Select the text with the mouse, right click on it and select Copy.");
alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
public void onClick(DialogInterface arg0, int arg1) {
//iscMessageBox5Closed
}
});
alertbox.show();
}


public void iscMessageBox6()
{
AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
alertbox.setMessage("The copy function is not yet available for this version of dualPrint.");
alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
public void onClick(DialogInterface arg0, int arg1) {
//iscMessageBox6Closed
}
});
alertbox.show();
}


public void iscTargetIs8()
{
iscMessageBox6();
//iscTargetIs8Android
}


public void iscClipboard_Copy10()
{
// get the char sequence//  CharSequence displayContents = resultHandler.getDisplayContents();//  ClipboardManager clipboard = (ClipboardManager) getSystemService(CLIPBOARD_SERVICE);// set the contents//  clipboard.setText(iscVwPar);//iscClipboard_Copy10Done}


public void iscTargetIs11()
{
//iscTargetIs11Android
}


public void iscTargetIs12()
{
iscClipboard_Copy4();
//iscTargetIs12Android
}


public void iscRunShellScript13()
{
//iscRunShellScript13Done
}


public void iscPortalDeparture14()
{
iscPortalDestination42();
//iscPortalDeparture14Done
}


public void iscConvertTextToNumber16()
{
iscVsl = Integer.parseInt(iscVslText);
//iscConvertTextToNumber16Done
}


public void iscIfThen17()
{
if (iscVslText == iscVnullText)
{
iscMessageBox131();
//iscIfThen17True

}
else
{
iscConvertTextToNumber19();
iscConvertTextToNumber18();
iscConvertTextToNumber16();
iscIfThen61();
//iscIfThen17False
}
}


public void iscConvertTextToNumber18()
{
iscVn = Integer.parseInt(iscVnText);
//iscConvertTextToNumber18Done
}


public void iscConvertTextToNumber19()
{
iscVstart = Integer.parseInt(iscVstartText);
//iscConvertTextToNumber19Done
}


public void iscConvertNumberToText20()
{
iscVwrite = String.valueOf(iscVcount);
//iscConvertNumberToText20Done
}


public void iscPortalDestination21()
{
iscSetNumber32();
iscCombineText118();
iscPortalDeparture25();
iscSetText134();
iscCombineText118();
iscAdd45();
iscSubtract138();
iscSubtract137();
iscSubtract50();
iscConvertNumberToText132();
iscCombineText49();
iscSetText143();
//iscPortalDestination21Arrived
}


public void iscPortalDestination22()
{
iscAdd45();
iscAdd133();
iscIfThen48();
//iscPortalDestination22Arrived
}


public void iscPortalDeparture23()
{
iscPortalDestination22();
//iscPortalDeparture23Done
}


public void iscPortalDestination24()
{
iscAdd29();
iscSubtract50();
iscConvertNumberToText132();
iscCombineText49();
iscPortalDeparture23();
//iscPortalDestination24Arrived
}


public void iscPortalDeparture25()
{
iscPortalDestination24();
//iscPortalDeparture25Done
}


public void iscPortalDestination26()
{
iscSetNumber32();
iscAdd29();
iscAdd28();
iscAdd27();
iscDoWhile162();
//iscPortalDestination26Arrived
}


public void iscAdd27()
{
iscVn = iscVn + iscVn1;
//iscAdd27Done
}


public void iscAdd28()
{
iscVcount = iscVcount + iscVn1;
//iscAdd28Done
}


public void iscAdd29()
{
iscVcount = iscVcount + iscVsl;
//iscAdd29Done
}


public void iscSetNumber30()
{
iscVcount = iscVstart;
iscConvertNumberToText20();
//iscSetNumber30Done
}


public void iscSetNumber31()
{
iscVqDifference = 0;
iscSetNumber30();
//iscSetNumber31Done
}


public void iscSetNumber32()
{
iscVqTest = 0;
iscSetNumber31();
//iscSetNumber32Done
}


public void iscCombineText33()
{
iscVwrite = iscVwrite + iscVcoma;
//iscCombineText33Done
}


public void iscSetText34()
{
iscVlink = iscVlink_license;
iscTargetIs146();
//iscSetText34Done
}


public void iscCloseWindow35()
{
//iscCloseWindow35Done
}


public void iscSetNumber36()
{
iscVwAbout = 0;
//iscSetNumber36Done
}


public void iscSetText37()
{
iscVlink = iscVlink_web;
iscTargetIs146();
//iscSetText37Done
}


public void iscSetCanvasPicture38()
{
iscWindow148icon0.setImageResource(R.drawable.dualprint);
//iscSetCanvasPicture38Done
}


public void iscTargetIs39()
{
iscSetNumber36();
iscWindow15();
//iscTargetIs39Android
}


public void iscSetNumber40()
{
iscVwAbout = 1;
iscWindow148();
//iscSetNumber40Done
}


public void iscIfThen41()
{
if (iscVwAbout == iscVn1)
{
//iscIfThen41True

}
else
{
iscSetNumber40();
//iscIfThen41False
}
}


public void iscPortalDestination42()
{
iscSubtract157();
iscDivide159();
iscDivide43();
iscAdd158();
iscConvertNumberToText44();
//iscPortalDestination42Arrived
}


public void iscDivide43()
{
iscVqDifference = iscVqDifference / iscVn2;
//iscDivide43Done
}


public void iscConvertNumberToText44()
{
iscVtotalPages = String.valueOf(iscVqDifference);
iscCombineText142();
//iscConvertNumberToText44Done
}


public void iscAdd45()
{
iscVqTest = iscVcount + iscVsl;
//iscAdd45Done
}


public void iscPortalDestination46()
{
iscSetNumber32();
iscCombineText118();
iscPortalDeparture74();
//iscPortalDestination46Arrived
}


public void iscIfThen47()
{
if (iscVqTest < iscVn)
{
iscCombineText118();
iscPortalDeparture25();
//iscIfThen47True

}
else
{
iscIfThen104();
//iscIfThen47False
}
}


public void iscIfThen48()
{
if (iscVqTest < iscVn)
{
iscCombineText33();
iscPortalDeparture113();
//iscIfThen48True

}
else
{
iscIfThen103();
//iscIfThen48False
}
}


public void iscCombineText49()
{
iscVwrite = iscVwrite + iscVcountText;
//iscCombineText49Done
}


public void iscSubtract50()
{
iscVcount = iscVcount - iscVn1;
//iscSubtract50Done
}


public void iscAdd52()
{
iscVcount = iscVstart + iscVsl;
iscConvertNumberToText20();
//iscAdd52Done
}


public void iscOpen_in_Web_Browser56()
{
//iscOpen_in_Web_Browser56Done
}


public void iscGetTextBox57()
{
iscWindow15n0 = (EditText)this.findViewById(R.id.iscWindow15n0);
String strThisString = iscWindow15n0.getText().toString();
iscVnText = strThisString;
iscIfThen63();
//iscGetTextBox57Done
}


public void iscGetTextBox58()
{
iscWindow15sl0 = (EditText)this.findViewById(R.id.iscWindow15sl0);
String strThisString = iscWindow15sl0.getText().toString();
iscVslText = strThisString;
iscGetTextBox57();
//iscGetTextBox58Done
}


public void iscGetTextBox59()
{
iscWindow15start0 = (EditText)this.findViewById(R.id.iscWindow15start0);
String strThisString = iscWindow15start0.getText().toString();
iscVstartText = strThisString;
iscGetTextBox58();
//iscGetTextBox59Done
}


public void iscIfThen60()
{
if (iscVsl < iscVn1)
{
iscMessageBox144();
//iscIfThen60True

}
else
{
iscIfThen80();
//iscIfThen60False
}
}


public void iscIfThen61()
{
if (iscVn < iscVn2)
{
iscMessageBox83();
//iscIfThen61True

}
else
{
iscIfThen79();
//iscIfThen61False
}
}


public void iscIfThen62()
{
if (iscVnText == iscVnullText)
{
iscMessageBox131();
//iscIfThen62True

}
else
{
iscIfThen17();
//iscIfThen62False
}
}


public void iscIfThen63()
{
if (iscVstartText == iscVnullText)
{
iscMessageBox131();
//iscIfThen63True

}
else
{
iscIfThen62();
//iscIfThen63False
}
}


public void iscPortalDeparture74()
{
iscPortalDestination75();
//iscPortalDeparture74Done
}


public void iscPortalDestination75()
{
iscPortalDeparture25();
iscSetText134();
iscCombineText118();
iscPortalDeparture25();
iscSetText143();
//iscPortalDestination75Arrived
}


public void iscIfThen76()
{
if (iscVsl < iscVn)
{
iscAdd120();
iscIfThen124();
//iscIfThen76True

}
else
{
iscMessageBox122();
//iscIfThen76False
}
}


public void iscSetTextBox77()
{
iscWindow15wPar0 = (EditText)this.findViewById(R.id.iscWindow15wPar0);
iscWindow15wPar0.setText(iscVwPar);
//iscSetTextBox77Done
}


public void iscIfThen79()
{
if (iscVstart < iscVn1)
{
iscMessageBox82();
//iscIfThen79True

}
else
{
iscIfThen60();
//iscIfThen79False
}
}


public void iscIfThen80()
{
if (iscVstart < iscVn)
{
iscIfThen76();
//iscIfThen80True

}
else
{
iscMessageBox156();
//iscIfThen80False
}
}


public void iscPortalDestination81()
{
iscSetNumber32();
iscCombineText118();
iscPortalDeparture25();
iscSetText134();
iscSetText143();
//iscPortalDestination81Arrived
}


public void iscMessageBox82()
{
AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
alertbox.setMessage("Your print should start from page 1 forward.");
alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
public void onClick(DialogInterface arg0, int arg1) {
//iscMessageBox82Closed
}
});
alertbox.show();
}


public void iscMessageBox83()
{
AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
alertbox.setMessage("The document must have 2 pages at least.");
alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
public void onClick(DialogInterface arg0, int arg1) {
//iscMessageBox83Closed
}
});
alertbox.show();
}


public void iscGetTextBox97()
{
iscWindow15wImpar0 = (EditText)this.findViewById(R.id.iscWindow15wImpar0);
String strThisString = iscWindow15wImpar0.getText().toString();
iscVwImpar = strThisString;
iscTargetIs1();
//iscGetTextBox97Done
}


public void iscGetTextBox98()
{
iscWindow15wPar0 = (EditText)this.findViewById(R.id.iscWindow15wPar0);
String strThisString = iscWindow15wPar0.getText().toString();
iscVwPar = strThisString;
iscTargetIs2();
//iscGetTextBox98Done
}


public void iscIf_Linux101()
{
//iscIf_Linux101Else
}


public void iscIfThen103()
{
if (iscVqTest == iscVn)
{
iscCombineText33();
iscAdd29();
iscAdd28();
iscConvertNumberToText132();
iscCombineText49();
//iscIfThen103True

}
else
{
//iscIfThen103False
}
}


public void iscIfThen104()
{
if (iscVqTest == iscVn)
{
iscCombineText118();
iscAdd29();
iscSubtract50();
iscConvertNumberToText132();
iscCombineText49();
//iscIfThen104True

}
else
{
iscCombineText118();
iscSubtract137();
iscSubtract50();
iscConvertNumberToText132();
iscConvertNumberToText132();
iscCombineText49();
//iscIfThen104False
}
}


public void iscSetTextBox105()
{
iscWindow15wImpar0 = (EditText)this.findViewById(R.id.iscWindow15wImpar0);
iscWindow15wImpar0.setText(iscVwImpar);
//iscSetTextBox105Done
}


public void iscPortalDestination111()
{
iscAdd29();
iscAdd28();
iscConvertNumberToText132();
iscCombineText49();
iscPortalDeparture112();
//iscPortalDestination111Arrived
}


public void iscPortalDeparture112()
{
iscPortalDestination128();
//iscPortalDeparture112Done
}


public void iscPortalDeparture113()
{
iscPortalDestination111();
//iscPortalDeparture113Done
}


public void iscAppQuit114()
{
this.finish();}


public void iscSetCanvasPicture115()
{
iscWindow15CI0.setImageResource(R.drawable.copy);
//iscSetCanvasPicture115Done
}


public void iscSetCanvasPicture116()
{
iscWindow15CP0.setImageResource(R.drawable.copy);
//iscSetCanvasPicture116Done
}


public void iscCombineText118()
{
iscVwrite = iscVwrite + iscVguion;
//iscCombineText118Done
}


public void iscAdd120()
{
iscVqTest = iscVstart + iscVsl;
//iscAdd120Done
}


public void iscMessageBox122()
{
AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
alertbox.setMessage("The number of pages per side should be less than the total of pages to print.");
alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
public void onClick(DialogInterface arg0, int arg1) {
//iscMessageBox122Closed
}
});
alertbox.show();
}


public void iscIfThen123()
{
if (iscVqTest == iscVqDifference)
{
iscPortalDeparture167();
//iscIfThen123True

}
else
{
iscAdd120();
iscAdd150();
iscIfThen175();
//iscIfThen123False
}
}


public void iscIfThen124()
{
if (iscVqTest > iscVn)
{
iscMessageBox126();
//iscIfThen124True

}
else
{
iscIfThen130();
//iscIfThen124False
}
}


public void iscMessageBox126()
{
AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
alertbox.setMessage("The sum of the starting page and the pages per side should be less than or equal to the total of pages to print.");
alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
public void onClick(DialogInterface arg0, int arg1) {
//iscMessageBox126Closed
}
});
alertbox.show();
}


public void iscPortalDeparture127()
{
iscPortalDestination26();
//iscPortalDeparture127Done
}


public void iscPortalDestination128()
{
iscAdd45();
iscSubtract138();
iscIfThen47();
//iscPortalDestination128Arrived
}


public void iscSetCanvasPicture129()
{
iscWindow15header0.setImageResource(R.drawable.header);
//iscSetCanvasPicture129Done
}


public void iscIfThen130()
{
if (iscVsl == iscVn1)
{
iscPortalDeparture127();
iscSetCanvasPicture129();
//iscIfThen130True

}
else
{
iscTargetIs172();
//iscIfThen130False
}
}


public void iscMessageBox131()
{
AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
alertbox.setMessage("Please fill all boxes first.");
alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
public void onClick(DialogInterface arg0, int arg1) {
//iscMessageBox131Closed
}
});
alertbox.show();
}


public void iscConvertNumberToText132()
{
iscVcountText = String.valueOf(iscVcount);
//iscConvertNumberToText132Done
}


public void iscAdd133()
{
iscVqTest = iscVqTest + iscVn1;
//iscAdd133Done
}


public void iscSetText134()
{
iscVwImpar = iscVwrite;
iscAdd52();
//iscSetText134Done
}


public void iscSubtract136()
{
iscVqDifference = iscVsl - iscVqDifference;
iscAdd149();
//iscSubtract136Done
}


public void iscSubtract137()
{
iscVqDifference = iscVqTest - iscVn;
iscSubtract136();
//iscSubtract137Done
}


public void iscSubtract138()
{
iscVqTest = iscVqTest - iscVn1;
//iscSubtract138Done
}


public void iscTargetIs139()
{
iscSetText141();
//iscTargetIs139Android
}


public void iscSetText140()
{
iscVlink = iscVlink_pHelp;
iscTargetIs146();
//iscSetText140Done
}


public void iscSetText141()
{
iscVlink = iscVlink_pHelp_A;
iscTargetIs146();
//iscSetText141Done
}


public void iscCombineText142()
{
iscVtotalPages = iscVtotal + iscVtotalPages;
iscSetButton155();
//iscCombineText142Done
}


public void iscSetText143()
{
iscVwPar = iscVwrite;
iscSetTextBox105();
iscSetTextBox77();
iscTargetIs12();
//iscSetText143Done
}


public void iscMessageBox144()
{
AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
alertbox.setMessage("You should print at least 1 page per side.");
alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
public void onClick(DialogInterface arg0, int arg1) {
//iscMessageBox144Closed
}
});
alertbox.show();
}


public void iscSetWebBrowser145()
{
iscWindow151WebBrowser0 = (WebView)this.findViewById(R.id.iscWindow151WebBrowser0);
iscWindow151WebBrowser0.setWebViewClient(new ISCWebViewClient());
iscWindow151WebBrowser0.getSettings().setJavaScriptEnabled(true);
iscWindow151WebBrowser0.loadUrl(iscVlink);
//iscSetWebBrowser145Done
}


public void iscTargetIs146()
{
iscWindow151();
//iscTargetIs146Android
}


public void iscIfThen147()
{
if (iscVwAbout == iscVn1)
{
iscWindow148();
//iscIfThen147True

}
else
{
iscWindow15();
//iscIfThen147False
}
}


public void iscAdd149()
{
iscVcount = iscVcount + iscVqDifference;
//iscAdd149Done
}


public void iscAdd150()
{
iscVqTest = iscVqTest + iscVsl;
//iscAdd150Done
}


public void iscWindow151(){
setContentView(R.layout.iscwindow151layout);
iscWindow151return0 = (Button)this.findViewById(R.id.iscWindow151return0);
iscWindow151return0.setOnClickListener(new OnClickListener() {
@Override
public void onClick(View v) {
iscIfThen147();
//iscWindow151returnClicked
}
});
findViewById(R.id.iscwindow151).setBackgroundColor(Color.argb(255, 255, 255, 255));
iscSetWebBrowser145();
//iscWindow151Opened
}

public void iscIf_Linux153()
{
//iscIf_Linux153Else
}


public void iscRunShellScript154()
{
//iscRunShellScript154Done
}


public void iscSetButton155()
{
iscWindow15bStart0 = (Button)this.findViewById(R.id.iscWindow15bStart0);
iscWindow15bStart0.setText(iscVtotalPages);
//iscSetButton155Done
}


public void iscMessageBox156()
{
AlertDialog.Builder alertbox = new AlertDialog.Builder(this);
alertbox.setMessage("The starting page should be lower than the total of pages to print.");
alertbox.setNeutralButton("Ok", new DialogInterface.OnClickListener() {
public void onClick(DialogInterface arg0, int arg1) {
//iscMessageBox156Closed
}
});
alertbox.show();
}


public void iscSubtract157()
{
iscVqDifference = iscVn - iscVstart;
//iscSubtract157Done
}


public void iscAdd158()
{
iscVqDifference = iscVqDifference + iscVn1;
//iscAdd158Done
}


public void iscDivide159()
{
iscVqDifference = iscVqDifference / iscVsl;
//iscDivide159Done
}


public void iscIfThen160()
{
if (iscVqDifference > iscVcapAndro)
{
//iscIfThen160True

}
else
{
iscIfThen170();
iscSetCanvasPicture129();
//iscIfThen160False
}
}


public void iscIfThen161()
{
if (iscVqDifference > iscVcapApple)
{
//iscIfThen161True

}
else
{
iscIfThen170();
//iscIfThen161False
}
}


public void iscDoWhile162()
{
while (iscVcount < iscVn)
{
iscCombineText33();
iscConvertNumberToText132();
iscCombineText49();
iscAdd29();
iscAdd28();
//iscDoWhile162Loop

}
iscSetText134();
iscAdd29();
iscAdd28();
iscDoWhile163();
//iscDoWhile162Finished
}


public void iscDoWhile163()
{
while (iscVcount < iscVn)
{
iscCombineText33();
iscConvertNumberToText132();
iscCombineText49();
iscAdd29();
iscAdd28();
//iscDoWhile163Loop

}
iscSetText143();
iscConvertTextToNumber18();
iscPortalDeparture14();
//iscDoWhile163Finished
}


public void iscIfThen165()
{
if (iscVqTest < iscVqDifference)
{
iscPortalDeparture167();
//iscIfThen165True

}
else
{
iscIfThen123();
//iscIfThen165False
}
}


public void iscPortalDeparture167()
{
iscPortalDestination46();
//iscPortalDeparture167Done
}


public void iscDivide168()
{
iscVqDifference = iscVn / iscVn2;
//iscDivide168Done
}


public void iscPortalDeparture169()
{
iscPortalDestination81();
//iscPortalDeparture169Done
}


public void iscIfThen170()
{
if (iscVqTest == iscVn)
{
iscPortalDeparture169();
iscPortalDeparture14();
//iscIfThen170True

}
else
{
iscDivide168();
iscIfThen165();
iscPortalDeparture14();
//iscIfThen170False
}
}


public void iscTargetIs172()
{
iscSubtract157();
iscAdd158();
iscDivide159();
iscIfThen160();
//iscTargetIs172Android
}


public void iscIfThen175()
{
if (iscVqTest > iscVn)
{
iscPortalDeparture176();
//iscIfThen175True

}
else
{
iscPortalDeparture167();
//iscIfThen175False
}
}


public void iscPortalDeparture176()
{
iscPortalDestination21();
//iscPortalDeparture176Done
}


public void iscWindow148(){
setContentView(R.layout.iscwindow148layout);
iscWindow148icon0 = (ImageView)this.findViewById(R.id.iscWindow148icon0);
iscWindow148icon0.setOnClickListener(new OnClickListener() {
@Override
public void onClick(View v) {
//iscWindow148iconClicked
}
});
iscWindow148close0 = (Button)this.findViewById(R.id.iscWindow148close0);
iscWindow148close0.setOnClickListener(new OnClickListener() {
@Override
public void onClick(View v) {
iscTargetIs39();
//iscWindow148closeClicked
}
});
iscWindow148web0 = (Button)this.findViewById(R.id.iscWindow148web0);
iscWindow148web0.setOnClickListener(new OnClickListener() {
@Override
public void onClick(View v) {
iscSetText37();
//iscWindow148webClicked
}
});
iscWindow148license0 = (Button)this.findViewById(R.id.iscWindow148license0);
iscWindow148license0.setOnClickListener(new OnClickListener() {
@Override
public void onClick(View v) {
iscSetText34();
//iscWindow148licenseClicked
}
});
findViewById(R.id.iscwindow148).setBackgroundColor(Color.argb(255, 0, 0, 0));
iscSetCanvasPicture38();
//iscWindow148Opened
}

public void iscWindow15(){
setContentView(R.layout.iscwindow15layout);
iscWindow15n0 = (EditText)this.findViewById(R.id.iscWindow15n0);
iscWindow15n0.setOnKeyListener(new OnKeyListener() {
@Override
public boolean onKey(View v, int keyCode, KeyEvent event) {
//iscWindow15nChanged
return false;
}
});
iscWindow15sl0 = (EditText)this.findViewById(R.id.iscWindow15sl0);
iscWindow15sl0.setOnKeyListener(new OnKeyListener() {
@Override
public boolean onKey(View v, int keyCode, KeyEvent event) {
//iscWindow15slChanged
return false;
}
});
iscWindow15bStart0 = (Button)this.findViewById(R.id.iscWindow15bStart0);
iscWindow15bStart0.setOnClickListener(new OnClickListener() {
@Override
public void onClick(View v) {
iscGetTextBox59();
//iscWindow15bStartClicked
}
});
iscWindow15start0 = (EditText)this.findViewById(R.id.iscWindow15start0);
iscWindow15start0.setOnKeyListener(new OnKeyListener() {
@Override
public boolean onKey(View v, int keyCode, KeyEvent event) {
//iscWindow15startChanged
return false;
}
});
iscWindow15wImpar0 = (EditText)this.findViewById(R.id.iscWindow15wImpar0);
iscWindow15wImpar0.setOnKeyListener(new OnKeyListener() {
@Override
public boolean onKey(View v, int keyCode, KeyEvent event) {
iscSetTextBox105();
//iscWindow15wImparChanged
return false;
}
});
iscWindow15wPar0 = (EditText)this.findViewById(R.id.iscWindow15wPar0);
iscWindow15wPar0.setOnKeyListener(new OnKeyListener() {
@Override
public boolean onKey(View v, int keyCode, KeyEvent event) {
iscSetTextBox77();
//iscWindow15wParChanged
return false;
}
});
iscWindow15CI0 = (ImageView)this.findViewById(R.id.iscWindow15CI0);
iscWindow15CI0.setOnClickListener(new OnClickListener() {
@Override
public void onClick(View v) {
iscGetTextBox97();
//iscWindow15CIClicked
}
});
iscWindow15CP0 = (ImageView)this.findViewById(R.id.iscWindow15CP0);
iscWindow15CP0.setOnClickListener(new OnClickListener() {
@Override
public void onClick(View v) {
iscGetTextBox98();
//iscWindow15CPClicked
}
});
iscWindow15about0 = (Button)this.findViewById(R.id.iscWindow15about0);
iscWindow15about0.setOnClickListener(new OnClickListener() {
@Override
public void onClick(View v) {
iscIfThen41();
//iscWindow15aboutClicked
}
});
iscWindow15paper0 = (Button)this.findViewById(R.id.iscWindow15paper0);
iscWindow15paper0.setOnClickListener(new OnClickListener() {
@Override
public void onClick(View v) {
iscTargetIs139();
//iscWindow15paperClicked
}
});
iscWindow15header0 = (ImageView)this.findViewById(R.id.iscWindow15header0);
iscWindow15header0.setOnClickListener(new OnClickListener() {
@Override
public void onClick(View v) {
//iscWindow15headerClicked
}
});
findViewById(R.id.iscwindow15).setBackgroundColor(Color.argb(255, 0, 0, 0));
iscSetCanvasPicture115();
iscSetCanvasPicture116();
iscSetCanvasPicture129();
//iscWindow15Opened
}

//EndOfFunctions

}

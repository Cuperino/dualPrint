/** Automatically generated file. DO NOT MODIFY */
package com.isc.dualPrint;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}